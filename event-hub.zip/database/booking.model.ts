import mongoose, { Document, Model, Schema, Types } from "mongoose";
import { EventDocument } from "./event.model";

// Strongly-typed interface for Booking documents
export interface BookingDocument extends Document {
  eventId: Types.ObjectId;
  email: string;
  createdAt: Date;
  updatedAt: Date;
}

// Email regex for basic validation (not exhaustive but practical for server-side checks)
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const BookingSchema = new Schema<BookingDocument, Model<BookingDocument>>(
  {
    eventId: { type: Schema.Types.ObjectId, ref: "Event", required: true },
    email: { type: String, required: true, trim: true },
  },
  { timestamps: true, strict: true }
);

// Indexes:
// - fast lookups by eventId and recent bookings
// - non-unique index on email for lookup performance (allows same email across events)
// - compound unique index on { eventId, email } to prevent duplicate bookings for the same event
// BookingSchema.index({ eventId: 1 });
BookingSchema.index({ eventId: 1, createdAt: -1 });
BookingSchema.index({ email: 1 }); // non-unique: allow same email to book different events
BookingSchema.index(
  { eventId: 1, email: 1 },
  { unique: true, name: "unique_eventid_email" }
);

// Pre-save hook:
// - Ensure referenced Event exists before saving a booking
// - Validate email format
BookingSchema.pre<BookingDocument>("save", async function (next) {
  try {
    // Validate email format
    if (typeof this.email !== "string" || !EMAIL_REGEX.test(this.email)) {
      throw new Error("Invalid email format");
    }

    // Verify referenced event exists. Use the Event model by name to avoid circular import issues.
    const EventModel = mongoose.model<EventDocument>("Event");
    const exists = await EventModel.exists({ _id: this.eventId });
    if (!exists) {
      throw new Error("Referenced eventId does not exist");
    }

    next();
  } catch (err) {
    next(err as Error);
  }
});

// Export model, reusing compiled model in development to avoid errors on hot-reload
export const Booking =
  (mongoose.models.Booking as Model<BookingDocument>) ??
  mongoose.model<BookingDocument>("Booking", BookingSchema);

export default Booking;
